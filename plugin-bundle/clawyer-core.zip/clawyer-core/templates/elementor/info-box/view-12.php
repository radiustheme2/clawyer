<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * This file can be overridden by copying it to yourtheme/elementor-custom/infobox/view-3.php
 * 
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 * @var $infobox_btn_visibility string
 * @var $heading_tag string
 * @var $title string
 * @var $active_item string
 * @var $number_text string
 * @var $icon_image array
 * @var $icon array
 * @var $btnicon array
 * @var $btntext string
 * @var $desc string
 */

use Elementor\Icons_Manager;

$attr = $tf = '';
if ( !empty( $url['url'] ) ) {
	$attr  = 'href="' . $url['url'] . '"';
	$attr .= !empty( $url['url']['is_external'] ) ? ' target="_blank"' : '';
	$attr .= !empty( $url['url']['nofollow'] ) ? ' rel="nofollow"' : '';
}

if ( !empty( $url['url'] ) && $infobox_btn_visibility == 'hidden' ) {
	$heading_tag_html = sprintf( '<%1$s class="item-title" data-cursor="-opaque"><a '.$attr.' class="item-btn">%3$s</a></%1$s>', $heading_tag, $title, $title );
} else {
	$heading_tag_html = sprintf( '<%1$s class="item-title" data-cursor="-opaque">%3$s</%1$s>', $heading_tag, $title, $title );
}

if ($active_item) {
    $active = 'active';
}

?>

<div class="clawyer-info-box clawyer-info-box-2 clawyer-info-box-12 <?php echo esc_attr( $active.' '.$css_classes.' '.$icon_position); ?> info-box">
    <div class="infobox-header-box">
        <?php if ( $number_text ){ ?>
            <span class="number"><?php echo esc_html( $number_text ); ?></span>
        <?php } if ($icon_image['url'] || $icon['value']) { ?>
            <div class="item-icon-box">
                <?php 
                    if ($icon_image['url']) {
                        echo wp_get_attachment_image( $icon_image['id'], 'full' ); 
                    } else {
                        Icons_Manager::render_icon( $icon );
                    }
                ?>
            </div>
        <?php } ?>
        <?php if ( !empty( $url['url'] ) && $infobox_btn_visibility == 'visible' ) { ?>
        <div class="btn-wrap">
            <a <?php echo wp_kses_post( $attr ); ?> class="item-btn">
                <?php Icons_Manager::render_icon( $btnicon, [ 'aria-hidden' => 'true' ] ); ?>
                <?php echo esc_html( $btntext ); ?>
            </a>
        </div>
        <?php } ?>
    </div>
    <div class="content">
        <?php echo wp_kses_post( $heading_tag_html ); ?>
        <div class="description-text">
	        <?php echo wp_kses_post( $desc ); ?>
        </div>
    </div>
</div>