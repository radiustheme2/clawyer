<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package clawyer
 */

use RT\Clawyer\Options\Opt;

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

	<?php wp_head(); ?>
</head>

<body <?php body_class('clawyer-header-footer'); ?>>
<?php wp_body_open(); ?>

<?php
if ( get_template() === 'clawyer' ) {
	if ( clawyer_option( 'rt_preloader' ) == 1 ) {
		do_action( 'site_prealoader' );
	}
}
?>

<div id="page" class="site">

	<?php do_action( 'rt_hf_header_markup' ); ?>

    <div id="content" class="site-content">
		<?php
		    if ( get_template() === 'clawyer' ) {
                get_template_part( 'views/content-banner', Opt::$banner_style );
            }
		?>
